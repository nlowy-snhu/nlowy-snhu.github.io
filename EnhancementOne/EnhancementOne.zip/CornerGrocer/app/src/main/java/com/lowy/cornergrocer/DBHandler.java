package com.lowy.cornergrocer;

import android.content.ClipData;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

// TODO: Implement DBHandler class
public class DBHandler extends SQLiteOpenHelper {
    // TODO: add variables
    private static final String TAG = "DBHandler";
    private static final String DB_NAME = "db_inventory";
    private static final int DB_VERSION = 1;

    public DBHandler(Context c) {
        super(c, DB_NAME, null, DB_VERSION);
    }

    // TODO: Implement ReadItems
    public ArrayList<ItemModel> ReadItems() {
        Log.d(TAG, "TODO: Implement ReadItems");
        ArrayList<ItemModel> itemModelArrayList = new ArrayList<>();
        return itemModelArrayList;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        Log.d(TAG, "TODO: Implement onCreate");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        Log.d(TAG, "TODO: Implement onUpgrade");
    }
}
