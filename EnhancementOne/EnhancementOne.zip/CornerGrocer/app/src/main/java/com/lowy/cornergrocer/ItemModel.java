package com.lowy.cornergrocer;

/**
 * A basic class for managing single items.
 * Includes constructors, getters, and setters.
 */
public class ItemModel {
    String name;
    String quantity;
    String category;

    public ItemModel(String name, String quantity, String category) {
        this.name = name;
        this.quantity = quantity;
        this.category = category;
    }

    public String getName() { return name; }

    public String getQuantity() { return quantity; }

    public String getCategory() { return category; }

    public void setName(String name) { this.name = name; }

    public void setQuantity(String quantity) { this.quantity = quantity; }

    public void setCategory(String category) { this.category = category; }
}
