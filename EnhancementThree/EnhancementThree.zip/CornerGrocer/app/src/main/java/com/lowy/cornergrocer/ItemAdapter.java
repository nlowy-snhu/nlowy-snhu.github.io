package com.lowy.cornergrocer;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.text.Layout;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.List;

/**
 * A class used to manage items for the RecyclerView.
 * In charge of establishing, binding, and applying
 * functionality to the items.
 * */
public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    //Variables
    Context context;
    List<ItemModel> itemList;
    DBHandler dbHandler;
    boolean histogram;

    /**
     * Basic constructor, also creates a DBHandler object
     *
     * @param context The current context
     * @param itemList List of ItemModels that contains all items in the
     *                 SQLite database
     */
    public ItemAdapter(Context context, List<ItemModel> itemList, boolean histogram) {
        this.context = context;
        this.itemList = itemList;
        this.dbHandler = new DBHandler(context, "SamplePassphrase");
        this.histogram = histogram;
    }

    /**
     * @param parent The ViewGroup into which the new View will be added after it is bound to
     *               an adapter position.
     * @param viewType The view type of the new View.
     *
     * @return New ViewHolder using the item_layout xml file
     */
    @NonNull
    @Override
    public ItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (histogram) {
            view = LayoutInflater.from(context).inflate(R.layout.histogram_layout, parent, false);
        } else {
            view = LayoutInflater.from(context).inflate(R.layout.item_layout, parent, false);
        }
        return new ViewHolder(view);
    }

    /**
     * Handles the setting of the names, categories, and quantities
     * Also used to set the onclick listener to call BottomSheetUpdate with relevant information.
     * Handles histogram and non-histogram layouts.
     *
     * @param holder The ViewHolder which should be updated to represent the contents of the
     *        item at the given position in the data set.
     * @param position The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(@NonNull ItemAdapter.ViewHolder holder, int position) {
        if (itemList != null && !itemList.isEmpty()) {
            ItemModel model = dbHandler.ReadItems().get(position);
            holder.productName.setText(model.getName());
            holder.productCategory.setText(model.getCategory());
            holder.productQuantity.setText(model.getQuantity());
            // Separate functionality for histogram
            if (this.histogram) {
                int asterisks = Integer.parseInt(model.getQuantity());
                StringBuilder output = new StringBuilder();
                for (int i = 0; i < asterisks; i++) {
                    if (i > 0 && i % 15 == 0) { output.append("\n"); }
                    output.append("*");
                }
                holder.productQuantity.setText(output);
            } else {
                holder.productQuantity.setText(model.getQuantity());
            }

            holder.itemView.setOnClickListener(v -> {
                int currentPosition = holder.getAdapterPosition();
                BottomSheetUpdate(model.getName(), model.getQuantity(), currentPosition);
            });


            holder.itemView.setOnLongClickListener(v -> {
                int currentPosition = holder.getAdapterPosition();
                return BottomSheetDelete(model.getName(), currentPosition);
            });
        }
    }

    @Override
    public int getItemCount() { return itemList.size(); }


    /**
     * Establishes a ViewHolder for the items in the RecyclerView
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {
        // ViewHolder variables
        TextView productName;
        TextView productQuantity;
        TextView productCategory;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            productName = itemView.findViewById(R.id.product_name);
            productQuantity = itemView.findViewById(R.id.product_quantity);
            productCategory = itemView.findViewById(R.id.product_category);
        }
    }

    /**
     * Displays and enables the options within BottomSheetUpdate with the
     * appropriate name and quantity. Allows incrementing, decrementing, inputting,
     * and saving updates to a product.
     *
     * @param productName The name to be applied at inflation
     * @param productQuantity The number to be applied at inflation
     */
    public void BottomSheetUpdate(String productName, String productQuantity, int adapterPosition) {
        //Inflate the bottom sheet
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context);
        @SuppressLint("InflateParams") View updater = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_update, null);
        bottomSheetDialog.setContentView(updater);
        bottomSheetDialog.show();

        // Variables
        Button decrement = updater.findViewById(R.id.bottom_sheet_update_decrement);
        Button increment = updater.findViewById(R.id.bottom_sheet_update_increment);
        Button confirm = updater.findViewById(R.id.bottom_sheet_update_confirm);
        EditText quantity = updater.findViewById(R.id.bottom_sheet_update_quantity);
        TextView header = updater.findViewById(R.id.bottom_sheet_update_heading);

        // Set the EditView and TextView values in the Bottom Sheet
        quantity.setText(productQuantity);
        quantity.setHint(productQuantity);
        header.setText(String.format(context.getString(R.string.updating), productName));

        // Initial check to see if increment/decrement need disabling
        // Note: on updating, this cannot be blank initially
        int value = Integer.parseInt(quantity.getText().toString());
        if ( value == 0) {
            decrement.setEnabled(false);
        } else if (value == 999) {
            increment.setEnabled(false);
        }


        // Uses the decrement button to decrement the product's quantity
        // without allowing negative numbers
        decrement.setOnClickListener(v -> {
            // Allows increment to be clicked once the value is upped
            increment.setEnabled(true);
            // Get a new value each click
            String quantityStr = quantity.getText().toString();
            if (!quantityStr.isBlank()) {
                int updatedCount = Integer.parseInt(quantityStr);
                if (updatedCount > 0) {
                    updatedCount--;
                }
                quantity.setText(String.valueOf(updatedCount));
            }
        });

        // Uses the increment button to increment the product's quantity
        // Prevents the number from being greater than 999
        increment.setOnClickListener(v -> {
            decrement.setEnabled(true);
            String quantityStr = quantity.getText().toString();
            if (!quantityStr.isBlank()) {
                int updatedCount = Integer.parseInt(quantityStr);
                if (updatedCount < 999) {
                    updatedCount++;
                }
                quantity.setText(String.valueOf(updatedCount));
            }
        });

        // Checks for any adjustments to text to determine if the buttons
        // should be disabled after re-enabling.
        quantity.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String value = charSequence.toString().trim();
                if (!value.isBlank()) {
                    int valueInt = Integer.parseInt(value);
                    increment.setEnabled(true);
                    decrement.setEnabled(true);
                    confirm.setEnabled(true);

                    if (valueInt == 999) {
                        increment.setEnabled(false);
                    } else if (valueInt == 0) {
                        decrement.setEnabled(false);
                    }
                } else {
                    confirm.setEnabled(false);
                }
            }
            @Override
            public void afterTextChanged(Editable editable) { }
        });

        // Saves value to the SQLite database when clicked
        confirm.setOnClickListener(v -> {
            String newQuantity = quantity.getText().toString();
            if (!newQuantity.isBlank()) {
                dbHandler.UpdateProduct(productName, newQuantity);
                this.notifyItemChanged(adapterPosition);
                bottomSheetDialog.dismiss();
            } else {
                Toast.makeText(context, "Please enter a number.", Toast.LENGTH_LONG).show();
            }
        });
    }

    /**
     * Handles deletion of an item on long press. Requires bottom sheet-based confirmation.
     *
     * @param productName The name of the product, used in the prompt for confirmation.
     * @return Boolean that confirms that the long press uses up the click, prevents onclick
     * followup.
     */
    public boolean BottomSheetDelete(String productName, int adapterPosition) {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(context);
        @SuppressLint("InflateParams") View updater = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_delete, null);
        bottomSheetDialog.setContentView(updater);
        bottomSheetDialog.show();

        Button deleteButton = updater.findViewById(R.id.bottom_sheet_delete_confirm);
        TextView prompt = updater.findViewById((R.id.bottom_sheet_delete_prompt));
        // Let the user know which item is up for deletion
        prompt.setText(String.format(context.getString(R.string.deleting), productName));

        deleteButton.setOnClickListener(v -> {
            itemList.remove(adapterPosition);
            dbHandler.DeleteProduct(productName);
            this.notifyItemRemoved(adapterPosition);
            bottomSheetDialog.dismiss();
        });

        return true;
    }
}
