/**
 * Title - Corner Grocer
 * A simple Android app for allowing tracking of inventory or sales,
 * with features that support addition, editing, and deleting of products.
 *
 * Deadline date for submission: 9-21-2025
 * Author: Nathaniel Lowy
 */

package com.lowy.cornergrocer;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;
import android.view.LayoutInflater;
import net.zetetic.database.sqlcipher.SQLiteDatabase;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    static {
        System.loadLibrary("sqlcipher");
    }

    // Tag used for log printouts
    // String TAG = "MainActivity";

    // Main items needed for showing the list on the screen
    RecyclerView recyclerView;
    ItemAdapter adapter;

    // A Database-handler for working with SQLite Database
    private DBHandler dbHandler;
    // Used to track whether the display should show a histogram
    boolean histogram;


    /**
     * The standard onCreate method, plus establishing important variables
     * and setting up the toolbar and RecyclerView
     * @param savedInstanceState Bundle to be used if saving is needed
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);

        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Establish the toolbar used for the application
        Toolbar myToolbar = findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        Objects.requireNonNull(getSupportActionBar()).setDisplayShowTitleEnabled(false);

        // Pass context to DBHandler object
        dbHandler = new DBHandler(MainActivity.this, "SamplePassphrase");
        // Set the Recycler View
        histogram = false;
        recyclerView = findViewById(R.id.recycler);
        SetRecyclerView(histogram);

        // Gets the floating action button and adds a listener so that products can be added
        FloatingActionButton addButton = findViewById(R.id.floatingActionButton);
        addButton.setOnClickListener(view -> BottomSheetAdd());

        // Gets the sorting method TextView and adds a listener
        // TODO: complete implementation of sorting once the database exists
        Button sortText = findViewById(R.id.sort_mode);
        sortText.setOnClickListener(view -> Toast.makeText(MainActivity.this, "TODO: Implement sorting", Toast.LENGTH_LONG).show());

        // Displays a tutorial on launching the Main Activity
        // BottomSheetHelp();
    }

    /**
     * Inflates and returns the menu
     *
     * @param menu - a public interface menu
     * @return boolean that determines whether the menu is displayed
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_histogram) {
            histogram = !histogram;
            SetRecyclerView(histogram);
        } else if (item.getItemId() == R.id.action_help) { BottomSheetHelp(); }
        return true;
    }

    /**
     * When preparing the Options Menu, allows for hiding the histogram control.
     *
     * @param menu - the Menu used in the toolbar for search and histogram
     * @return - boolean with success
     */
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem histogramControl = menu.findItem(R.id.action_histogram);
        histogramControl.setVisible(true);
        return super.onPrepareOptionsMenu(menu);
    }


    /**
     * Sets the recycler view to display items from the database
     *
     */
    public void SetRecyclerView(boolean histogram) {
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemAdapter(this, GetList(), histogram);
        recyclerView.setAdapter(adapter);
    }


    /**
     * A basic implementation of a list generator to test the RecyclerView.
     * To be removed once SQLite database is implemented.
     *
     * @return A list of default items (Products #0-16)
     */
    private List<ItemModel> ItemAdapterTest() {
        List<ItemModel> testing = new ArrayList<>();
        for (int i = 0; i < 17; i++) {
            testing.add(new ItemModel("Product #" + i, Integer.toString(i * 2), "Example Category"));
        }

        return testing;
    }


    /**
     * Used to return a list from DBHandler of all products for the
     * creation of the adapter for the RecyclerView.
     *
     * @return A list from DBHandler's ReadItems
     */
    private List<ItemModel> GetList() { return dbHandler.ReadItems(); }


    /**
     * Overrides the standard onResume implementation to include
     * setting the recycler view. Useful for keeping the screen
     * up-to-date.
     */
    @Override
    public void onResume() {
        super.onResume();
        SetRecyclerView(histogram);
    }


    /**
     * Handles all methods relating to loading, showing, and implementing
     * the bottom sheet responsible for adding items to the database
     */
    public void BottomSheetAdd() {
        // Establish and show the bottom sheet for adding products
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(MainActivity.this);
        @SuppressLint("InflateParams") View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.bottom_sheet_add, null);
        bottomSheetDialog.setContentView(view);
        bottomSheetDialog.show();

        // View variables
        EditText editProduct = view.findViewById(R.id.bottom_sheet_add_name);
        EditText editCategory = view.findViewById(R.id.bottom_sheet_add_category);
        EditText editQuantity = view.findViewById(R.id.bottom_sheet_add_quantity);
        Button button = view.findViewById(R.id.bottom_sheet_add_close);

        // OnClick Listener for the Add Product button
        button.setOnClickListener(v -> {
            // Variables for validating input
            String productName = editProduct.getText().toString().trim();
            String productQuantity = editQuantity.getText().toString();
            String productCategory = editCategory.getText().toString();

            // Checks to see if input is valid: field cannot be empty
            if (!productName.isBlank() && !productQuantity.isBlank()) {
                if (!dbHandler.AddNewProduct(productName, productCategory, productQuantity)){
                    Toast.makeText(MainActivity.this, productName + " already exists.", Toast.LENGTH_LONG).show();
                }
                bottomSheetDialog.dismiss();
                SetRecyclerView(histogram);
            } else {
                Toast.makeText(MainActivity.this, "Invalid input, ensure both product name and quantity,", Toast.LENGTH_LONG).show();
            }
        });
    }

    /**
     * An initial bottom sheet for displaying a brief list of functionality
     */
    public void BottomSheetHelp() {
        // Establish and show the bottom sheet for adding products
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(MainActivity.this);
        @SuppressLint("InflateParams") View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.bottom_sheet_help, null);
        bottomSheetDialog.setContentView(view);
        bottomSheetDialog.show();

        Button button = view.findViewById(R.id.bottom_sheet_help_understood);

        button.setOnClickListener(v -> bottomSheetDialog.dismiss());
    }



}