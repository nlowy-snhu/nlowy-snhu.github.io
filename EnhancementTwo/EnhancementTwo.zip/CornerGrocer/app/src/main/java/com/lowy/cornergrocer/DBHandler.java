/**
 * SQLite Database handler using SQLCipher instead of default android implementation.
 * This allows for creating encrypted and decrypting the database.
 */

package com.lowy.cornergrocer;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.res.AssetManager;
import android.database.Cursor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

// The SQLCipher versions to allow encryption/decryption
import net.zetetic.database.sqlcipher.SQLiteDatabase;
import net.zetetic.database.sqlcipher.SQLiteOpenHelper;


/**
 * Handler class for SQLite through SQLCipher's SQLiteOpenHelper.
 * Handles all database operations, with basic Create, Read, Update, Delete functionality.
 * Note: should CornerGrocer decide, a passphrase can be used to add an extra layer of
 * encryption/decryption security.
 *
 */
public class DBHandler extends SQLiteOpenHelper {
    // Currently not accessed, though here should encryption be desired.
    /** @noinspection unused, FieldCanBeLocal */
    private final String passphrase;

    private static final String DB_NAME = "db_inventory";
    private static final int DB_VERSION = 1;

    // Constants for building the SQLite table
    private static final String ID_COL = "id";
    private static final String TABLE_NAME = "inventory";
    private static final String NAME_COL = "name";
    private static final String CATEGORY_COL = "category";
    private static final String QUANTITY_COL = "quantity";
    private final Context context;
    // Set up as Singleton
    @SuppressLint("StaticFieldLeak")
    private static DBHandler instance;

    // Variables for sorting purposes
    private static String ordering;
    private int sortMethod = 0;
    public String sortString = "Name (Asc.)";
    private static final int SORT_MAX = 5;

    /**
     * The basic constructor, with additional passphrase that
     * can be applied for encryption/decryption needs.
     *
     * @param c The context passed in to DBHelper (MainActivity)
     *          when called from Main or ItemAdapter.
     * @param passphrase The passphrase to use if encryption/
     *                   decryption is desired.
     * @noinspection SameParameterValue
     */
    private DBHandler(Context c, String passphrase) {
        super(c, DB_NAME, null, DB_VERSION);
        this.context = c;
        this.passphrase = passphrase;
    }

    /**
     * Allows for getting the instance of the Singleton DBHandler.
     *
     * @param context The context passed in (MainActivity).
     * @return The instance of the Singleton DBHandler.
     */
    public static DBHandler getInstance(Context context) {
        if (instance == null) {
            instance = new DBHandler(context, "SamplePassphrase");
        }
        return instance;
    }

    public ArrayList<ItemModel> ChangeSort() {
        SQLiteDatabase db = this.getReadableDatabase();
        // Update the sortMethod for the next call
        sortMethod++;
        if (sortMethod > SORT_MAX) {
            sortMethod = 0;
        }

        switch (sortMethod) {
            // Controls the new results
            case 0:
                sortString = "Name (Asc.)";
                ordering = "UPPER(" + NAME_COL + ") ASC";
                break;
            case 1:
                sortString = "Name (Desc.)";
                ordering = "UPPER(" + NAME_COL + ") DESC";
                break;
            case 2:
                sortString = "Quantity (Asc.)";
                ordering = "CAST(" + QUANTITY_COL + " AS INT) ASC";
                break;
            case 3:
                sortString = "Quantity (Desc.)";
                ordering = "CAST(" + QUANTITY_COL + " AS INT) DESC";
                break;
            case 4:
                sortString = "Category (Asc.)";
                ordering = "UPPER(" + CATEGORY_COL + ") ASC";
                break;
            case 5:
                sortString = "Category (Desc.)";
                ordering = "UPPER(" + CATEGORY_COL + ") DESC";
                break;
            default:
                break;
        }

        ArrayList<ItemModel> itemModelArrayList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " ORDER BY " + ordering,null);

        if (cursor.moveToFirst()) {
            do {
                itemModelArrayList.add(new ItemModel(cursor.getString(1), cursor.getString(2), cursor.getString(3)));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();


        return itemModelArrayList;

    }


    /**
     * Performs a simple query to get all items.
     *
     * @return List of all items in the database.
     */
    public ArrayList<ItemModel> ReadItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<ItemModel> itemModelArrayList = new ArrayList<>();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " ORDER BY " + ordering,null);

        if (cursor.moveToFirst()) {
            do {
                itemModelArrayList.add(new ItemModel(cursor.getString(1), cursor.getString(2), cursor.getString(3)));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();


        return itemModelArrayList;
    }

    /**
     * Creates the database when it doesn't already exist and loads
     * data from the input file using the LoadItems() method.
     *
     * @param sqliteDatabase The database.
     */
    @Override
    public void onCreate(SQLiteDatabase sqliteDatabase) {
        // Build the query for table creation
        String produceQuery = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT, "
                + CATEGORY_COL + " TEXT, "
                + QUANTITY_COL + " TEXT)";

        // Creates the table for tracking inventory using the above
        sqliteDatabase.execSQL(produceQuery);

        // Creates an index on the product name column to allow faster read operations
        String indexQuery = "CREATE INDEX product_name ON " + TABLE_NAME + "(" + NAME_COL + ")";
        sqliteDatabase.execSQL(indexQuery);

        LoadItems(sqliteDatabase);
    }

    /**
     * Allows for upgrading the database by removing/recreating.
     *
     * @param sqLiteDatabase The database.
     * @param i The old database version.
     * @param i1 The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // Drop the tables if they exist, then call onCreate
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }


    /**
     * Simple function for securely adding a new product to the table.
     * Uses ContentValues for security and preventing injection
     *
     * @param productName The name of the new product being added.
     * @param productCategory The category that the new product belongs to.
     * @param quantity The amount of units of the new product.
     * @return Boolean that gauges success.
     */
    public boolean AddNewProduct(String productName, String productCategory, String quantity) {
        // Ensure that the added product does not exist already
        if (ProductCheck(NAME_COL, productName)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(NAME_COL, productName);
        values.put(CATEGORY_COL, productCategory);
        values.put(QUANTITY_COL, quantity);

        db.insert(TABLE_NAME, null, values);

        db.close();

        return true;
    }

    /**
     * Updates a product via its (unique) name.
     *
     * @param productName The deciding String to determine what row to update.
     * @param productQuantity The new quantity for the product.
     */
    public void UpdateProduct(String productName, String productQuantity) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(NAME_COL, productName);
        values.put(QUANTITY_COL, productQuantity);
        db.update(TABLE_NAME, values, "name=?", new String[]{productName});
        db.close();
    }

    /**
     * Finds the product by name and deletes it securely, using parameterization.
     *
     * @param productName The name of the product to be deleted.
     */
    public void DeleteProduct(String productName) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NAME, NAME_COL + " = ?", new String[]{productName});
        db.close();
    }


    /**
     * Loads items from the database (through the call in OnCreate) when there
     * is no database yet (first run or after storage is cleared).
     *
     * @param db The database, used for the insertion transactions. NOTE:
     *           this is called in onCreate, so a writeable database should not
     *           be attempted here, simply passed through.
     */
    public void LoadItems(SQLiteDatabase db) {
        AssetManager assetManager = this.context.getResources().getAssets();
        BufferedReader reader = null;

        // Make sure that the reading of the file works correctly, and catch
        // any errors to ensure smooth and proper operation.
        try {
            String inputFile = "input.txt";
            InputStream ins = assetManager.open(inputFile);
            reader = new BufferedReader(new InputStreamReader(ins));
            String currentLine;
            db.beginTransaction();
            while ((currentLine = reader.readLine()) != null) {
                String[] columns = currentLine.split(",");
                if (columns.length == 3) {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put(NAME_COL,columns[0]);
                    contentValues.put(CATEGORY_COL, columns[1]);
                    contentValues.put(QUANTITY_COL, columns[2]);
                    db.insert(TABLE_NAME, null, contentValues);
                }
            }
            db.setTransactionSuccessful();
        } catch (IOException e) {
            //noinspection CallToPrintStackTrace
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    //noinspection CallToPrintStackTrace
                    e.printStackTrace();
                }
            }
            db.endTransaction();
        }
    }

    /**
     * Check if a product already exists before adding it. Executes basic
     * parameterized query to check.
     *
     * @param column The column used for comparison.
     * @param name The product's name to be checked.
     * @return Boolean that states where the product has a match.
     */
    public boolean ProductCheck(String column, String name) {
        SQLiteDatabase db = this.getReadableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + column + " LIKE ?";

        Cursor cursor = db.rawQuery(query, new String[]{name});
        if (cursor.getCount() > 0) {
            cursor.close();
            db.close();
            return true;
        } else {
            cursor.close();
            db.close();
            return false;
        }
    }
}
